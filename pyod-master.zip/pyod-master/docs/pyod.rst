API Reference
=============

.. toctree::

    pyod.models
    pyod.utils

Module contents
---------------

.. automodule:: pyod
    :members:
    :exclude-members: __version__
    :undoc-members:
    :show-inheritance:
    :inherited-members:

